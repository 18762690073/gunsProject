package cn.stylefeng.guns.multi.mapper;

import cn.stylefeng.guns.multi.entity.Test;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author fengshuonan
 * @since 2018-07-10
 */
public interface TestMapper extends BaseMapper<Test> {

}
