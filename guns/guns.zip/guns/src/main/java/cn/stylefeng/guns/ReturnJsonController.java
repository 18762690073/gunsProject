package cn.stylefeng.guns;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import cn.stylefeng.guns.modular.system.model.JsonReturn;

@RestController
public class ReturnJsonController {
	
//	@RequestMapping(value = "/json/getJsonData", method = RequestMethod.GET)
//	public JsonReturn getJsonData() {
//		JsonReturn json = new JsonReturn();
//		json.setCode(0);
//		json.setMsg("获取测试JSON成功！");
//		json.setData(new HashedMap().put("admin", "admin"));
//		return json;
//	}

}
